package clone.colley.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MyResponse {
    private Boolean result;
}
