package clone.colley.dto.Request;

import lombok.Data;

@Data
public class CommentRequestDto {
    private String comment;

}
