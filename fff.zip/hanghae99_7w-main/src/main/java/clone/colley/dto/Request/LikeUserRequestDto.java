package clone.colley.dto.Request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class LikeUserRequestDto {
   private Boolean isLike;
}
